using System;
using System.Linq;
using System.Xml;
using Verse;

namespace CuprosAlloys
{
	internal class PatchOperationFindMod : PatchOperation
	{
		protected override bool ApplyWorker(XmlDocument xml)
		{
			bool flag = this.modName.NullOrEmpty();
			return !flag && ModsConfig.ActiveModsInLoadOrder.Any((ModMetaData m) => m.Name == this.modName);
		}

		private string modName;
	}
}
